/**
 * Just some simple demo code.
 */
package com.kohlschutter.boilerpipe.demo;


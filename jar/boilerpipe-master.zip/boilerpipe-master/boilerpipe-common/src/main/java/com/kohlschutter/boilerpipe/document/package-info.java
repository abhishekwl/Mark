/**
 * The Boilerpipe document model.
 */
package com.kohlschutter.boilerpipe.document;

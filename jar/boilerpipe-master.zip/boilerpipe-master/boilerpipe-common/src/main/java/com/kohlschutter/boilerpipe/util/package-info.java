/**
 * Some helper classes.
 */
package com.kohlschutter.boilerpipe.util;


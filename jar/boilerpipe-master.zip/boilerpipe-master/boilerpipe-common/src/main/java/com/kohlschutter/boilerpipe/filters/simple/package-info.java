/**
 * These BoilerpipeFilters are straight-forward and probably not really specific to English.
 */
package com.kohlschutter.boilerpipe.filters.simple;


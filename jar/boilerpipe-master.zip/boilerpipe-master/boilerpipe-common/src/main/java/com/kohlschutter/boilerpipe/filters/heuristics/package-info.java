/**
 * These BoilerpipeFilters are pure heuristics.
 */
package com.kohlschutter.boilerpipe.filters.heuristics;

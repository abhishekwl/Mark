/**
 * These BoilerpipeFilters have only been tested on English text.
 * 
 * That is, they will probably work with other Western languages, but maybe need some parameter tuning to perform well.
 */
package com.kohlschutter.boilerpipe.filters.english;


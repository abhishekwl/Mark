/**
 * Some standard extractors (i.e., completely piped BoilerpipeFilters)
 */
package com.kohlschutter.boilerpipe.extractors;
